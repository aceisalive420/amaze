const { CommandInteraction, Client } = require('discord.js');
const { SlashCommandBuilder } = require('discord.js');
const Discord = require('discord.js');
const moment = require("moment");
require("moment-duration-format");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Get help with the bot'),

    /** 
     * @param {Client} client
     * @param {CommandInteraction} interaction
     * @param {String[]} args
     */

    run: async (client, interaction, args) => {
        await interaction.deferReply({ fetchReply: true });
        const row = new Discord.ActionRowBuilder()
            .addComponents(
                new Discord.StringSelectMenuBuilder()
                    .setCustomId('Bot-helppanel')
                    .setPlaceholder('Amaze Menu')
                    .addOptions([
                        {
                            label: `Commands`,
                            description: `Show the commands of Bot!`,
                            emoji: "<:settings:1207339224353738803>",
                            value: "commands-Bothelp",
                        },
                        {
                            label: `Invite`,
                            description: `Invite Bot to your server`,
                            emoji: "<:plus:1207338393097347082>",
                            value: "invite-Bothelp",
                        },
                        {
                            label: `Support Server`,
                            description: `Join the support server`,
                            emoji: "<:question_:1207953117350592542>",
                            value: "support-Bothelp",
                        },
                    ]),
            );

        return client.embed({
            title: `<:usericon:1207338300323663902><:arrow:1203975950837088268>**__About Amaze__**`,
            desc: `> Hey there! I come loaded with 450+ commands, including entertainment, moderation, utilities and way more. Elevate your server with me!`,
            image: "",
            /*fields: [
                {
                    name: `❌<:dot:1198345719065624606>Menu doesn't work?`,
                    value: `Try resending the command. If you get no reaction, make sure you report the bug!`
                },
                {
                    name: `🪲<:dot:1198345719065624606>Found a bug?`,
                    value: `Report this with \`/report bug\``
                },
                {
                    name: `🔗<:dot:1198345719065624606>Links`,
                    value: `[Website](https://corwindev.nl/) | [Invite](${client.config.discord.botInvite}) | [Vote](https://top.gg/bot/798144456528363550/vote)`
                },
            ],*/
            components: [row],
            type: 'editreply'
        }, interaction)
    },
};

 