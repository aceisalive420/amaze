const { CommandInteraction, Client } = require('discord.js');
const { ContextMenuCommandBuilder } = require('discord.js');
const Discord = require('discord.js');

const model = require('../../database/models/badge');
const Schema = require('../../database/models/profile');
const CreditsSchema = require("../../database/models/votecredits");

module.exports = {
    data: new ContextMenuCommandBuilder()
        .setName('Bot profile')
        .setType(2),

    /** 
     * @param {Client} client
     * @param {CommandInteraction} interaction
     * @param {String[]} args
     */

    run: async (client, interaction, args) => {
        const badgeFlags = {
            DEVELOPER: client.emotes.badges.developer,
            EVENT: client.emotes.badges.event,
            BOOSTER: client.emotes.badges.booster,
            BUGS: client.emotes.badges.bug,
            MANAGEMENT: client.emotes.badges.management,
            PREMIUM: client.emotes.badges.premium,
            SUPPORTER: client.emotes.badges.supporter,
            TEAM: client.emotes.badges.team,
            BOOSTER: client.emotes.badges.booster,
            PARTNER: client.emotes.badges.partner,
            VOTER: client.emotes.badges.voter,
            SUPPORT: client.emotes.badges.support,
            MODERATOR: client.emotes.badges.moderator,
            DESIGNER: client.emotes.badges.designer,
            MARKETING: client.emotes.badges.marketing,
            ACTIVE: client.emotes.badges.active,
            VIP: client.emotes.badges.vip
        }

        const flags = {
            ActiveDeveloper: "👨‍💻<:arrow:1203975950837088268>Active Developer",
            BugHunterLevel1: "🐛<:arrow:1203975950837088268>Discord Bug Hunter",
            BugHunterLevel2: "🐛<:arrow:1203975950837088268>Discord Bug Hunter",
            CertifiedModerator: "👮‍♂️<:arrow:1203975950837088268>Certified Moderator",
            HypeSquadOnlineHouse1: "🏠<:arrow:1203975950837088268>House Bravery Member",
            HypeSquadOnlineHouse2: "🏠<:arrow:1203975950837088268>House Brilliance Member",
            HypeSquadOnlineHouse3: "🏠<:arrow:1203975950837088268>House Balance Member",
            HypeSquadEvents: "🏠<:arrow:1203975950837088268>HypeSquad Events",
            PremiumEarlySupporter: "👑<:arrow:1203975950837088268>Early Supporter",
            Partner: "👑<:arrow:1203975950837088268>Partner",
            Quarantined: "🔒<:arrow:1203975950837088268>Quarantined", // Not sure if this is still a thing
            Spammer: "🔒<:arrow:1203975950837088268>Spammer", // Not sure if this one works
            Staff: "👨‍💼<:arrow:1203975950837088268>Discord Staff",
            TeamPseudoUser: "👨‍💼<:arrow:1203975950837088268>Discord Team",
            VerifiedBot: "🤖<:arrow:1203975950837088268>Verified Bot",
            VerifiedDeveloper: "👨‍💻<:arrow:1203975950837088268>(early)Verified Bot Developer",
        }


        const user = interaction.guild.members.cache.get(interaction.targetId);

        Schema.findOne({ User: user.id }, async (err, data) => {
            if (data) {
                await interaction.deferReply({ fetchReply: true });
                let Badges = await model.findOne({ User: user.id });

                let credits = 0;
                const creditData = await CreditsSchema.findOne({ User: user.id });

                if (Badges && Badges.FLAGS.includes("DEVELOPER")) {
                    credits = "∞";
                }
                else if (creditData) {
                    credits = creditData.Credits;
                }

                if (!Badges) Badges = { User: user.id };

                const userFlags = user.flags ? user.flags.toArray() : [];

                client.embed({
                    title: `${client.user.username}<:arrow:1203975950837088268>Profile`,
                    desc: '_____',
                    thumbnail: user.avatarURL({ dynamic: true }),
                    fields: [{
                        name: "👤<:dot:1198345719065624606>User",
                        value: user.username,
                        inline: true
                    },
                    {
                        name: "📘<:dot:1198345719065624606>Discriminator",
                        value: user.discriminator,
                        inline: true
                    },
                    {
                        name: "🆔<:dot:1198345719065624606>ID",
                        value: user.id,
                        inline: true
                    },
                    {
                        name: "👨‍👩‍👦<:dot:1198345719065624606>Gender",
                        value: `${data.Gender || 'Not set'}`,
                        inline: true
                    },
                    {
                        name: "🔢<:dot:1198345719065624606>Age",
                        value: `${data.Age || 'Not set'}`,
                        inline: true
                    },
                    {
                        name: "🎂<:dot:1198345719065624606>Birthday",
                        value: `${data.Birthday || 'Not set'}`,
                        inline: true
                    },
                    {
                        name: "🎨<:dot:1198345719065624606>Favorite color",
                        value: `${data.Color || 'Not set'}`,
                        inline: true
                    },
                    {
                        name: "🐶<:dot:1198345719065624606>Favorite pets",
                        value: `${data.Pets.join(', ') || 'Not set'}`,
                        inline: true
                    },
                    {
                        name: "🍕<:dot:1198345719065624606>Favorite food",
                        value: `${data.Food.join(', ') || 'Not set'}`,
                        inline: true
                    },
                    {
                        name: "🎶<:dot:1198345719065624606>Favorite songs",
                        value: `${data.Songs.join(', ') || 'Not set'}`,
                        inline: true
                    },
                    {
                        name: "🎤<:dot:1198345719065624606>Favorite artists",
                        value: `${data.Artists.join(', ') || 'Not set'}`,
                        inline: true
                    },
                    {
                        name: "🎬<:dot:1198345719065624606>Favorite movies",
                        value: `${data.Movies.join(', ') || 'Not set'}`,
                        inline: true
                    },
                    {
                        name: "👨‍🎤<:dot:1198345719065624606>Favorite actors",
                        value: `${data.Actors.join(', ') || 'Not set'}`,
                        inline: true
                    },
                    {
                        name: "🏴<:dot:1198345719065624606>Origin",
                        value: `${data.Orgin || 'Not set'}`,
                        inline: true
                    },
                    {
                        name: "🎮<:dot:1198345719065624606>Hobby's",
                        value: `${data.Hobbys.join(', ') || 'Not set'}`,
                        inline: true
                    },
                    {
                        name: "😛<:dot:1198345719065624606>Status",
                        value: `${data.Status || 'Not set'}`,
                        inline: true
                    },
                    {
                        name: "📛<:dot:1198345719065624606>Bot Badges",
                        value: `${Badges.FLAGS ? Badges.FLAGS.map(flag => badgeFlags[flag]).join(' ') : 'None'}`,
                        inline: true
                    },
                    {
                        name: "🏷️<:dot:1198345719065624606>Discord Badges",
                        value: `${userFlags.length ? userFlags.map(flag => flags[flag]).join(', ') : 'None' || 'None'}`,
                        inline: true
                    },
                    {
                        name: "💳<:dot:1198345719065624606>Dcredits",
                        value: `${credits || 'None'}`,
                        inline: true
                    },
                    {
                        name: "ℹ️<:dot:1198345719065624606>About me",
                        value: `${data.Aboutme || 'Not set'}`,
                        inline: false
                    },], type: 'editreply'
                }, interaction);
            }
            else {
                return client.errNormal({ error: "No profile found! Open a profile with /profile create", type: 'ephemeral' }, interaction);
            }
        })
    },
};

 