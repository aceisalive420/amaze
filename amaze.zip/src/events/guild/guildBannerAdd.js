const Discord = require('discord.js');

module.exports = async (client, guild, bannerURL) => {
    const logsChannel = await client.getLogs(guild.id);
    if (!logsChannel) return;

    client.embed({
        title: `🖼️<:arrow:1203975950837088268>New banner`,
        desc: `The server banner has been updated`,
        image: bannerURL
    }, logsChannel).catch(() => { })
};