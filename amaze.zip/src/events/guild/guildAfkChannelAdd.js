const Discord = require('discord.js');

module.exports = async (client, guild, afkChannel) => {
    const logsChannel = await client.getLogs(guild.id);
    if (!logsChannel) return;

    client.embed({
        title: `🛑<:arrow:1203975950837088268>New AFK channel`,
        desc: `An AFK channel has been added to the server`,
        fields: [
            {
                name: `> Channel`,
                value: `- ${afkChannel}`
            },
            {
                name: `> Name`,
                value: `- ${afkChannel.name}`
            },
            {
                name: `> ID`,
                value: `- ${afkChannel.id}`
            },
            {
                name: `> Timestamp`,
                value: `- <t:${Math.floor(afkChannel.createdTimestamp / 1000)}:R>`
            }
        ]
    }, logsChannel).catch(() => { })
};