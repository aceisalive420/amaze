const Discord = require('discord.js');

module.exports = (client, error) => {
    if (error.message == undefined) {
        console.log(error);
        error.message = "Send to console!";
    }
    const errorlog = new Discord.WebhookClient({
        id: client.webhooks.voiceErrorLogs.id,
        token: client.webhooks.voiceErrorLogs.token,
    });

    let embed = new Discord.EmbedBuilder()
        .setTitle(`<:siren_:1208258931311513650><:arrow:1203975950837088268>Voice error`)
        .addFields(
            { name: "Error", value: `\`\`\`${error.message}\`\`\``},
            { name: `Stack error`, value: `\`\`\`${error.stack.substr(0, 1018)}\`\`\``},
        )
        .setColor(client.config.colors.normal)
    errorlog.send({
        username: `Amaze`,
        embeds: [embed],

    }).catch(error => { console.log(error) })
};