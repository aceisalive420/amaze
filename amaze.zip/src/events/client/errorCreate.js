const Discord = require('discord.js');
const generator = require('generate-password');

module.exports = (client, err, command, interaction) => {
    console.log(err);
    const password = generator.generate({
        length: 10,
        numbers: true
    });

    const errorlog = new Discord.WebhookClient({
        id: client.webhooks.errorLogs.id,
        token: client.webhooks.errorLogs.token,
    });

    let embed = new Discord.EmbedBuilder()
        .setTitle(`<:siren_:1208258931311513650><:arrow:1203975950837088268>${password}`)
        .addFields(
            { name: "<:tick:1207338336008802405><:dot:1198345719065624606>Guild", value: `> ${interaction.guild.name} (${interaction.guild.id})`},
            { name: `<:tv_:1208279753858089040><:dot:1198345719065624606>Command`, value: `> ${command}`},
            { name: `<:message_:1208279657296953354><:dot:1198345719065624606>Error`, value: `> \`\`\`${err}\`\`\``},
            { name: `<:files:1207338559749488690><:dot:1198345719065624606>Stack error`, value: `> \`\`\`${err.stack.substr(0, 1018)}\`\`\``},
        )
        .setColor(client.config.colors.normal)
    errorlog.send({
        username: `Amaze`,
        embeds: [embed],

    }).catch(error => { console.log(error) })

    let row = new Discord.ActionRowBuilder()
        .addComponents(
            new Discord.ButtonBuilder()
                .setEmoji("<:question_:1207953117350592542>")
                .setURL(client.config.discord.serverInvite)
                .setStyle(Discord.ButtonStyle.Link),
        );

    client.embed({
        title: `${client.emotes.normal.error}<:arrow:1203975950837088268>Error`,
        desc: `> There was an error while executing this command,`,
        color: client.config.colors.error,
        fields: [
            {
                name: `Assistance!`,
                value: `> You can contact the developers by joining the support server`,
                inline: true,
            }
        ],
        components: [row],
        type: 'editreply'
    }, interaction).catch(() => {
        client.embed({
            title: `${client.emotes.normal.error}<:arrow:1203975950837088268>Error`,
            desc: `> There was an error while executing this command,`,
            color: client.config.colors.error,
            fields: [
                {
                    name: `Assistance!`,
                    value: `> You can contact the developers by joining the support server`,
                    inline: true,
                }
            ],
            components: [row],
            type: 'editreply'
        }, interaction)
    })
};