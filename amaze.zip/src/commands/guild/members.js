const Discord = require('discord.js');

module.exports = async (client, interaction, args) => {
  const members = await interaction.guild.members.fetch();

  client.embed({
    title: `👤<:arrow:1203975950837088268>Membercount`,
    desc: `View the total number of members in the server`,
    fields: [
      {
        name: `👤<:dot:1198345719065624606>Members`,
        value: `${members.filter(member => !member.user.bot).size} members`,
        inline: true
      },
      {
        name: `🤖<:dot:1198345719065624606>Bots`,
        value: `${members.filter(member => member.user.bot).size} bots`,
        inline: true
      },
      {
        name: `📘<:dot:1198345719065624606>Total`,
        value: `${interaction.guild.memberCount} members`,
        inline: true
      }
    ],
    type: 'editreply'
  }, interaction)
}

   