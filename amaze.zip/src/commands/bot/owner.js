const Discord = require('discord.js');

module.exports = async (client, interaction, args) => {
    client.embed({
        title: `📘<:arrow:1203975950837088268>Owner information`,
        desc: `____________________________`,
        thumbnail: client.user.avatarURL({ dynamic: true, size: 1024 }),
        fields: [{
            name: "👑<:dot:1198345719065624606>Owner name",
            value: `Corwin`,
            inline: true,
        },
        {
            name: "🏷<:dot:1198345719065624606>Discord tag",
            value: `</Corwin>#0001`,
            inline: true,
        },
        {
            name: "🏢<:dot:1198345719065624606>Organization",
            value: `CoreWare`,
            inline: true,
        },
        {
            name: "🌐<:dot:1198345719065624606>Website",
            value: `[https://corwindev.nl](https://corwindev.nl)`,
            inline: true,
        }],
        type: 'editreply'
    }, interaction)
}

 