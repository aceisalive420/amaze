const Discord = require('discord.js');

module.exports = async (client, interaction, args) => {
    client.embed({
        title: "📃<:arrow:1203975950837088268>Changelogs",
        desc: `_____`,
        thumbnail: client.user.avatarURL({ size: 1024 }),
        fields: [{
            name: "📃<:dot:1198345719065624606>Changelogs",
                value: '15/3/2023 Updated dependencies',
                inline: false,
            },
        ],
        type: 'editreply'
    }, interaction)
}

 
