const Discord = require('discord.js');

const Schema = require("../../database/models/verify");

module.exports = async (client, interaction, args) => {
    const perms = await client.checkUserPerms({
        flags: [Discord.PermissionsBitField.Flags.ManageMessages],
        perms: [Discord.PermissionsBitField.Flags.ManageMessages]
    }, interaction)

    if (perms == false) return;

    const boolean = interaction.options.getBoolean('enable');
    const channel = interaction.options.getChannel('channel');
    const role = interaction.options.getRole('role');

    if (boolean == true) {
        const data = await Schema.findOne({ Guild: interaction.guild.id });
        if (data) {
            data.Channel = channel.id;
            data.Role = role.id
            data.save();
        }
        else {
            new Schema({
                Guild: interaction.guild.id,
                Channel: channel.id,
                Role: role.id
            }).save();
        }

        client.succNormal({
            text: `> Verify panel has been successfully created`,
            fields: [
                {
                    name: `<:tags_:1208279610383667231><:dot:1198345719065624606>Channel`,
                    value: `> ${channel}`,
                    inline: true
                },
                {
                    name: `<:balls_:1208255794827497482><:dot:1198345719065624606>Role`,
                    value: `> ${role}`,
                    inline: true
                }
            ],
            type: 'editreply'
        }, interaction);

        const row = new Discord.ActionRowBuilder()
            .addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId('Bot_verify')
                    .setLabel('Verify')
                    .setEmoji('<:tick:1207338336008802405>')
                    .setStyle(Discord.ButtonStyle.Secondary),
            );

        client.embed({
            title: `<:moderation:1207346462287994931><:arrow:1203975950837088268>Verification System`,
            desc: `> Click on the button to verify yourself`,
            components: [row]
        }, channel)
    }
}

 