const Discord = require('discord.js');

module.exports = async (client) => {
    const fields = [
        {
            name: `<:commands_:1208256530303160360><:dot:1198345719065624606>Bot`,
            value: `> </bot help:1207571004126269483>`,
            inline: true
        },
        {
            name: `<:commands_:1208256530303160360><:dot:1198345719065624606>Configuration`,
            value: `> </config help:1206287494329536561>`,
            inline: true
        },
        {
            name: `<:commands_:1208256530303160360><:dot:1198345719065624606>Custom commands`,
            value: `> </custom-commands help:1206287494329536560>`,
            inline: true
        },
        {
            name: `<:commands_:1208256530303160360><:dot:1198345719065624606>Giveaway`,
            value: `> </giveaway help:1206287494505570371>`,
            inline: true
        },
        {
            name: `<:commands_:1208256530303160360><:dot:1198345719065624606>Guild settings`,
            value: `> </guild help:1206287494505570372>`,
            inline: true
        },
        {
            name: `<:commands_:1208256530303160360><:dot:1198345719065624606>Invites`,
            value: `> </invites help:1206287494652633199>`,
            inline: true
        },
        {
            name: `<:commands_:1208256530303160360><:dot:1198345719065624606>Leveling`,
            value: `> </levels help:1206287494652633200>`,
            inline: true
        },
        {
            name: `<:commands_:1208256530303160360><:dot:1198345719065624606>Moderation`,
            value: `> </mod help:1207967276976971787>`,
            inline: true
        },
        {
            name: `<:commands_:1208256530303160360><:dot:1198345719065624606>Music`,
            value: `> </music help:1206287494652633204>`,
            inline: true
        },
        {
            name: `<:commands_:1208256530303160360><:dot:1198345719065624606>Reaction roles`,
            value: `> </reactionroles help:1206287494837051393>`,
            inline: true
        },
        {
            name: `<:commands_:1208256530303160360><:dot:1198345719065624606>Setup`,
            value: `> </setup help:1206287494837051397>`,
            inline: true
        },
        {
            name: `<:commands_:1208256530303160360><:dot:1198345719065624606>Tickets`,
            value: `> </tickets help:1206287495021461514>`,
            inline: true
        },
    ];

    client.on(Discord.Events.InteractionCreate, async (interaction) => {
        if (!interaction.isStringSelectMenu()) return;

        if (interaction.customId == "Bot-helppanel") {
            if (interaction.values == "commands-Bothelp") {
                interaction.deferUpdate();
                let page = 1;

                const row = new Discord.ActionRowBuilder()
                    .addComponents(

                        new Discord.ButtonBuilder()
                            .setEmoji("<:share_:1208279542628618300>")
                            .setURL("https://github.com/aceisalive420")
                            .setStyle(Discord.ButtonStyle.Link),

                    );

                const row2 = new Discord.ActionRowBuilder()
                    .addComponents(
                        new Discord.StringSelectMenuBuilder()
                            .setCustomId('Bot-helppanel')
                            .setPlaceholder('Amaze Menu')
                            .addOptions([
                                {
                                    label: `Commands`,
                                    description: `Show the commands of Bot!`,
                                    emoji: "<:settings:1207339224353738803>",
                                    value: "commands-Bothelp",
                                },
                                {
                                    label: `Invite`,
                                    description: `Invite Bot to your server`,
                                    emoji: "<:plus:1207338393097347082>",
                                    value: "invite-Bothelp",
                                },
                                {
                                    label: `Support Server`,
                                    description: `Join the support server`,
                                    emoji: "<:question_:1207953117350592542>",
                                    value: "support-Bothelp",
                                },
                            ]),
                    );

                client.embed({
                    title: `<:settings:1207339224353738803><:arrow:1203975950837088268>**__Commands__**`,
                    desc: `**__Prefix Information__**\nMy Prefix is no longer supported. Please use /help!\nYou can also mention <@1205393527178002432> to get more information.`,
                    image: "",
                    fields: fields.slice(0, 24),
                    components: [row2, row],
                    type: 'edit'
                }, interaction.message).then(msg => {
                    const filter = i => i.user.id === interaction.user.id;

                    const collector = interaction.channel.createMessageComponentCollector({ filter, time: 100000 });

                    collector.on('collect', async i => {
                        if (i.customId == "helpNext") {
                            if (page == 1) {
                                client.embed({
                                    title: `<:settings:1207339224353738803><:arrow:1203975950837088268>**__Commands__**`,
                                    desc: `**__Prefix Information__**\nMy Prefix is no longer supported. Please use /help!\nYou can also mention <@1205393527178002432> to get more information.`,
                                    components: [row2, row],
                                    type: 'update'
                                }, i)
                                page += 1;
                            }
                        }

                        else if (i.customId == "helpPrev") {
                            if (page == 2) {
                                client.embed({
                                    title: `<:settings:1207339224353738803><:arrow:1203975950837088268>**__Commands__**`,
                                    desc: `**__Prefix Information__**\nMy Prefix is no longer supported. Please use /help!\nYou can also mention <@1205393527178002432> to get more information.`,
                                    fields: fields.slice(0, 24),
                                    components: [row2, row],
                                    type: 'update'
                                }, i)
                                page -= 1;
                            }
                        }
                    });
                })
            }
        }
    }).setMaxListeners(0);
}

 